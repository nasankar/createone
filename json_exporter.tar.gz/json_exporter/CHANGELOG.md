## 0.4.0 / 2022-01-15

* [FEATURE] Add support for HTTP POST body content #123

## 0.3.0 / 2021-02-12

:warning: Backward incompatible configuration with previous versions.
* [CHANGE] Migrate JSONPath library [#74](https://github.com/prometheus-community/json_exporter/pull/74)
* [CHANGE] Add TLS metrics support [#68](https://github.com/prometheus-community/json_exporter/pull/68)

## 0.2.0 / 2020-11-03

* [CHANGE] This release is complete refactoring [#49](https://github.com/prometheus-community/json_exporter/pull/49)
* [BUGFIX] Fix unchecked call to io.Copy [#57](https://github.com/prometheus-community/json_exporter/pull/57)

## 0.1.0 / 2020-07-27

Initial prometheus-community release.
